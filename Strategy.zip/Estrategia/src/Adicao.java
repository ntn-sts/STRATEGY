public class Adicao implements IOperacao{

    @Override
    public int Operacao(int a, int b) {
        return a + b;
    }

}
