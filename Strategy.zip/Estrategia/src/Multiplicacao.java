public class Multiplicacao implements IOperacao{
    @Override
    public int Operacao(int a, int b) {
        return 0;
    }
}