public interface IOperacao {
    int Operacao(int a, int b); //receber dois numeros, retornar 1 numero
}