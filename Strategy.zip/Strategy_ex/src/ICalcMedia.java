import java.util.ArrayList;

public interface ICalcMedia {
    double CalculaMedia(double p1, double p2);

    String Situacao(double media);
}
